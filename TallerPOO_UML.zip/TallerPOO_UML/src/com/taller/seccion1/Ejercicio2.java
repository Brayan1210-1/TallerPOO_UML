package com.taller.seccion1;

public class Ejercicio2 {

	public static void main(String[] args) {
		int num = 1;
	    double decimal = 5.5;
	    char caracter = 'k';
	    boolean existe = true;
	    
	    
	  System.out.println(num);
	  System.out.println("");
	  System.out.println(decimal);
	  System.out.println("");
	  System.out.println(caracter);
	  System.out.println("");
	  System.out.println(existe);
		}

}
