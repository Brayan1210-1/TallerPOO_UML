package com.taller.seccion1;



public class Ejercicio7 {

	public static void main(String[] args ) {
		
		String cadenaN = "123";
		//convertir el String a double y int
      int numeroEntero = Integer.parseInt(cadenaN);
      double numeroDecimal = Double.parseDouble(cadenaN);
      
      //convertir int y double a String
      String cadenaDeEntero = Integer.toString(numeroEntero);
      String cadenaDeDouble = Double.toString(numeroDecimal);
      
      //Imprimir la conversion de String a double y int
      System.out.println(numeroEntero);
 		System.out.println(numeroDecimal);
 		System.out.println("");
 		
 	  //Imprimir la conversión de int y double a String
 		System.out.println(cadenaDeEntero);
 		System.out.println(cadenaDeDouble);
	}
	
}
