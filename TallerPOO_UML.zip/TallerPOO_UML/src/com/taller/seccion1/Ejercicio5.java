package com.taller.seccion1;

public class Ejercicio5 {
 
	//Método main para que se ejecute el código
	public static void main(String[] args) {
		
		//Declaración de variables
		int num = 1;
	    double decimal = 5.5;
	    char caracter = 'k';
	    boolean existe = true;
	    
	    //Impresión de las variables
	  System.out.println(num);
	  System.out.println("");
	  System.out.println(decimal);
	  System.out.println("");
	  System.out.println(caracter);
	  System.out.println("");
	  System.out.println(existe);
	  System.out.println("");
	  
	  //Impresion de operadores aritméticas con las variables "num" y "decimal"
	  System.out.println(num + decimal);
	  System.out.println( num * decimal);
	  System.out.println(num / decimal);
	  System.out.println(num % decimal);
	  System.out.println("");
	  
	  //Impresion de operadores relacionales con las variables "num" y "decimal"
	  //sysout con "<" "&&" y ">"
	  System.out.println( (num < decimal) && (decimal > num) );
	  //sysout con "==" "||" "!="
	  System.out.println( (num == decimal) || (num != decimal) );
	  //sysout con "!" y "<"
	  System.out.println( !(num < decimal) );
	  
	  
	}
	
}
