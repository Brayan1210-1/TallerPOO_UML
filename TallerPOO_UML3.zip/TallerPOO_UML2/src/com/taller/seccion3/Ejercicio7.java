package com.taller.seccion3;
import java.util.HashSet;

public class Ejercicio7 {

	public static void main(String[] args) {
		
	HashSet<Double> hash = new HashSet<Double>();
	hash.add(2.3);
	hash.add(1.87);
	
	System.out.println(" El tamaño es de: " + hash.size());
	

	}

}
