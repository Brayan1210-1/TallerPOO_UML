package com.taller.seccion3;



public class Ejercicio13 {

	public static void main(String[] args) {

String nombre = "Robtop";
		System.out.println(nombre.contains("R"));
	}

}
