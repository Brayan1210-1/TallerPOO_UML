package com.taller.seccion3;

import java.util.ArrayList;
import java.util.List;

public class Ejercicio14 {

	public static void main(String[] args) {
	
List<String> nombres = new ArrayList<>();
		
		nombres.add("Carlitos");
		nombres.add("Juancho");
		nombres.add("Robtop");
		nombres.add("Cris");
		
		//For antes de clear
for(String nombre: nombres) {
	System.out.println(nombre);
}
		
		nombres.clear();
		
		//for después de clear
for(String nombre: nombres) {
System.out.println(nombre);
		
	}

}
}
