package com.taller.seccion3;

import java.util.HashMap;
import java.util.Map.Entry;

public class Ejercicio9 {

	public static void main(String[] args) {
		
		//Declaración del HashMap
				HashMap<String, Integer> mapeo = new HashMap<String, Integer>();
				 //Put para agregar un nombre y una clave
				 mapeo.put("Alex", 28);
		        mapeo.put("Juana", 23);
		        mapeo.put("Emilio", 10);
		       
	for(Entry<String, Integer> mapa: mapeo.entrySet()) {
		String nombre = mapa.getKey();
		int valor = mapa.getValue();
		
		System.out.println(nombre);
		System.out.println(valor);
		System.out.println();
	}
		    
	}

}


