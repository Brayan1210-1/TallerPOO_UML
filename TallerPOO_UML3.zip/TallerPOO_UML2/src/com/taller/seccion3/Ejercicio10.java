package com.taller.seccion3;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;

public class Ejercicio10 {

	public static void main(String[] args) {
		
		//Declaración del HashMap
				HashMap<String, Integer> mapeo = new HashMap<String, Integer>();
				 //Put para agregar un nombre y una clave
				 mapeo.put("Alex", 28);
		        mapeo.put("Juana", 23);
		        mapeo.put("Emilio", 10);
		       
	
	//Declaracion de lista para valores y bucle for para asignar valores 
		   List<Integer> valores = new ArrayList<>();
 for(Integer valor: mapeo.values()){
	valores.add(valor); 
 }
 //collections  para ordenar los valores de la lista
 Collections.sort(valores);
 
 for(int v: valores) {
	 mapeo.put( "", v);
 }
 
 for(Entry<String, Integer> mapa: mapeo.entrySet()) {
	 String n = mapa.getKey();
	 Integer v = mapa.getValue();
	 
	 System.out.println(n + v);
 }
 
	}

}
