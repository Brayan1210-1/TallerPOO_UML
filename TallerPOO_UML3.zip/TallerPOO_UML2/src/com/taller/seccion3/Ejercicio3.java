package com.taller.seccion3;

public class Ejercicio3 {

	public static void main(String[] args) {

String[] productos = { "Tampico", "Vive100", "Bonice"};

  //For con índice
for(int i = 0; i < productos.length; i++) {
	System.out.println(productos[i]);
}
	
	System.out.println();
	
	//For each
for(String producto: productos) {
	System.out.println(producto);
}
	}
}
