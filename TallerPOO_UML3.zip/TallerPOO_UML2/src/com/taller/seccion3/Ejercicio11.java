package com.taller.seccion3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



public class Ejercicio11 {

	public static void main(String[] args) {
	
		List<String> nombres = new ArrayList<>();
		
		nombres.add("Carlitos");
		nombres.add("Juancho");
		nombres.add("Robtop");
		nombres.add("Cris");
		
 Iterator<String>iterador = nombres.iterator();
		while (iterador.hasNext() == true) {
			
			if (iterador.next() == "Juancho") {
				iterador.remove();
			}else {
			System.out.println(iterador.next());
			
		}

}
    
		
	}
	}


