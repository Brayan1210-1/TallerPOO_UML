package com.taller.seccion1;

public class Ejercicio1 {

	public static void main(String[] args) {
	int num = 1;
    double decimal = 5.5;
    char caracter = 'k';
    boolean existe = true;
	}

}
