package com.taller.seccion1;

public class Clase14 {

	public static void main(String[] args) {
		
		String prueba = "";
      prueba.isEmpty();
  
       
	}

}
