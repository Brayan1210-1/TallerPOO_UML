package com.taller.seccion1;
import java.util.Scanner;

public class Ejercicio6 {
	
	public static void main(String[] args) {
		
	//Instanciación del scanner para leer los números
	Scanner sc = new Scanner(System.in);
	
	//sysout para decirle al usuario que ingrese un número entero
	System.out.println(" Ingrese un número entero ");
	int numero = sc.nextInt();
	
	//sysout para pedirle al usuario que ingrese un númnero decimal
	System.out.println(" Ingrese un número decimal ");
	double deci = sc.nextDouble();
	}

	
	
}
