package com.taller.seccion4;

public class Ejercicio2 {

	public class Persona{
		private String nombre; 
		private int edad;
       
		public Persona(String nombr, int edad) {
			this.nombre = nombr;
			this.edad = edad;
			
		}
		

	}
}
