package com.taller.seccion4;

public class Ejercicio3 {
	
	public class Persona{
		private String nombre; 
		private int edad;
       
		public Persona(String nombre, int edad) {
			this.setNombre(nombre);
			this.setEdad(edad);
			
		}

		public String getNombre() {
			if (edad >= 0) {
				return nombre;
			} else {
				return "No ha nacido";
			}
		
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public int getEdad() {
			
			if (edad >= 0) {
				return edad;
			}else {
			return -1;}
	      	
		}

		public void setEdad(int edad) {
			this.edad = edad;
		}
	}
}
