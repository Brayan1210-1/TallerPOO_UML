package com.taller.seccion4;

public class MainPersona {

	public static void main(String[] args) {
		
		Persona persona = new Persona("Emilio", 23);
         persona.presentarse();
         System.out.println();
	
        Persona persona1 = new Persona();
        persona1.presentarse();
        System.out.println();
        Persona persona2 = new Persona(43);
        persona2.presentarse();
        
        System.out.println(persona);
	}
}
