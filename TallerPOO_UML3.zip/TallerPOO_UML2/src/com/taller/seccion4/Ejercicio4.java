package com.taller.seccion4;

public class Ejercicio4 {
	public class Persona{
		
		//atributos
		private String nombre; 
		private int edad;
       
    //Constructor
		public Persona(String nombre, int edad) {
			this.setNombre(nombre);
			this.setEdad(edad);
			
		}

		//Método presentarse
		public void presentarse() {
System.out.println("Hola, soy"+ getNombre()+ " y tengo " + getEdad()+ " años");
			
		}
		
		//getters y setters
		public String getNombre() {
			if (edad >= 0) {
				return nombre;
			} else {
				return "No ha nacido";
			}
		
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public int getEdad() {
			
			if (edad >= 0) {
				return edad;
			}else {
			return -1;}
	      	
		}

		public void setEdad(int edad) {
			this.edad = edad;
		}
	}
}
