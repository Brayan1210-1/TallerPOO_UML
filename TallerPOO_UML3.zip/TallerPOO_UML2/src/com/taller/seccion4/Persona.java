package com.taller.seccion4;

public class Persona {
	    //atributos
	private String nombre; 
	private int edad;
	private static String colorOjos = "Azúl";
	private Direccion direccion;
	
	/**
	 * 
	 * @param edad
	 */
	public Persona(int edad) {
		nombre = "Robtop";
		this.setEdad(edad);
		
	}
	/**
	 * Constructor en caso de que no hayan parámetros
	 * 
	 */
	public Persona() {
		nombre = "Jaimito";
		edad = 80;
	}
	    /**
	     * 
	     * @param de nombre
	     * @param de edad
	     */
		public Persona(String nombre, int edad) {
		this.setNombre(nombre);
		this.setEdad(edad);
					}
		public Persona(String nombre, int edad, Direccion direccion) {
			this.setNombre(nombre);
			this.setEdad(edad);
			this.setDireccion(direccion);
		}
			/**
			 * Método saludar
			 */
			public void presentarse() {
	System.out.println("Hola, soy "+ getNombre()+ " y tengo " + getEdad()+ " años");
			}
			
		public void presentarse(String nombre, int edad, Direccion direccion ) {
System.out.println("Hola, soy " + nombre + " Tengo " + edad + " años " + "vivo en"
		+ direccion);
	 	
		}
			
			/**
			 * @Override
			 */
			public String toString() {
				return "Persona [nombre=" + nombre + ", edad=" + edad + "]";
			}
			
			/**
			 * 
			 * @return el nombre de la persona
			 */
			public String getNombre() {
				if (edad >= 0) {
					return nombre;
				} else {
					return "No ha nacido";
				}
			
			}

			/**
			 * 
			 * @param un nuevo nombre
			 */
			public void setNombre(String nombre) {
				this.nombre = nombre;
			}
			
			/**
			 * 
			 * @return la edad de la persona
			 */

			public int getEdad() {
				
				if (edad >= 0) {
					return edad;
				}else {
				return -1;}
		      	
			}

			/**
			 * 
			 * @param cambiar edad
			 */
			public void setEdad(int edad) {
				this.edad = edad;
			}

			/**
			 * 
			 * @return el color de ojos
			 */
			public static String getColorOjos() {
				return colorOjos;
			}

			/**
			 * 
			 * @param cambia el colorOjos
			 */
			public static void setColorOjos(String colorOjos) {
				Persona.colorOjos = colorOjos;
			}
			/**
			 * 
			 * @return la dirección
			 */
			public Direccion getDireccion() {
				return direccion;
			}
			
			
			
			public void setDireccion(Direccion direccion) {
				this.direccion = direccion;
			}
}



