package com.taller.seccion2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Ejercicio13 {

	public static void main(String[] args) {
	

	ArrayList<Integer> listaNumeros = new ArrayList<>();
			listaNumeros.add(54);
			listaNumeros.add(1);
			listaNumeros.add(10);
			listaNumeros.add(17);
			listaNumeros.add(9);
			listaNumeros.add(9);
			listaNumeros.add(1);
			
		Set<Integer> setListaNum = new HashSet<Integer>(listaNumeros);
			
		System.out.println(" Números repetidos");
		for(int numero: listaNumeros) {
			
			System.out.println(numero);
		}
		
			System.out.println("");
		System.out.println(" Números sin repetir ");
		for(int numeroSin: setListaNum) {
			System.out.println(numeroSin);
		}
		
	}

}
