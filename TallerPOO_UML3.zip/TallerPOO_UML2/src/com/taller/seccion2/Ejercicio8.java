package com.taller.seccion2;


public class Ejercicio8 {

	public static void main(String[] args) {

		
	System.out.println(" Ingrese el número para saber su tabla de multiplicar");
	
	 int tabla = 10;
	 
		for (int i = 1; i < tabla; i++) {
	
			System.out.println(" La tabla de multiplicación del: " + i);
			for(int q = 1; q < tabla; q++ ) {
				System.out.println(i + "x" + q + "=" + i*q);
			}
		}

	}

}
