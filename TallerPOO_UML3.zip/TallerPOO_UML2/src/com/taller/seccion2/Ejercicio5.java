package com.taller.seccion2;
import java.util.Scanner;

public class Ejercicio5 {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
	int suma = 0;
		int parar = 1; 
		
		while (parar != 0) {
		System.out.println(" ingrese el número 0 para detener la suma");
		
		suma += 1;
		System.out.println(" Resultado de la suma: " + suma); 
		
			parar = sc.nextInt();
			
			
		}
        
		sc.close();
	}

}
