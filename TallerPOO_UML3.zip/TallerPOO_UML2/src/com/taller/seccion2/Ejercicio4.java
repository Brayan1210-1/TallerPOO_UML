package com.taller.seccion2;

public class Ejercicio4 {

	public static void main(String[] args) {
		
		int factorial = 0;
		//bucle for para imprimir del 1 al 20
for ( int i = 1; i <=20; i++) {
	System.out.println(i);
	
	factorial = i * (i-1);
	
}
   System.out.println(" el factorial es: " + factorial);
	}

}
