package com.taller.seccion2;
import java.util.ArrayList;

public class Ejercicio11 {
public static void main(String[] args) {
	

	
	ArrayList<Integer> listaNumeros = new ArrayList<>();
	listaNumeros.add(1);
	listaNumeros.add(2);
	listaNumeros.add(10);
	listaNumeros.add(17);
	listaNumeros.add(9);
	
	for (int numero : listaNumeros) {
		if (numero % 2 == 0) {
			System.out.println(numero);
		}
	}
}
}