package com.taller.seccion3;

public class Ejercicio1 {

	public static void main(String[] args) {
    
		int[] edades = new int[5];
		edades[0] = 24;
		edades[1] = 12;

	}

}
