package com.taller.seccion3;
import java.util.Arrays;
import java.util.List;

public class Ejercicio5 {

	public static void main(String[] args) {
		
	String[] saludos = { "Hola", "Hello", "Aló" };
	
	List<String> saludos1 = Arrays.asList(saludos);
	System.out.println(saludos1);
	
	Object[] saludosA = saludos1.toArray();
	
	System.out.println(saludosA[0]);
	}
	
	
}
