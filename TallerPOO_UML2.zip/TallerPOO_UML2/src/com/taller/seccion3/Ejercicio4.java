package com.taller.seccion3;
import java.util.ArrayList;

public class Ejercicio4 {

	public static void main(String[] args) {
	
  ArrayList<Integer> numeritos = new ArrayList<>();
   numeritos.add(4);
   numeritos.add(20);
   numeritos.add(30);
   
   for(int numero : numeritos) {
	   System.out.println(numero);
   }
   System.out.println();
   
   numeritos.remove(0);
   System.out.println(" Array sin el 4 ");
   for(int num : numeritos) {
	   System.out.println(num);
   }
	}

}
