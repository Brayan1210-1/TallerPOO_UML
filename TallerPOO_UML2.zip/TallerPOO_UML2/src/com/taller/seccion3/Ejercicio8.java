package com.taller.seccion3;
import java.util.HashMap;

public class Ejercicio8 {

	public static void main(String[] args) {
		
		HashMap<String, Integer> mapeo = new HashMap<String, Integer>();
		   mapeo.put("Alex", 28);
           mapeo.put("Juana", 23);
           mapeo.put("Emilio", 10);
          System.out.println(mapeo.get("Emilio"));
	}

}
