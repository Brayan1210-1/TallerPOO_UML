package com.taller.seccion3;
import java.util.ArrayList;
import java.util.LinkedList;

public class Ejercicio6 {

	public static void main(String[] args) {
	
		LinkedList<String> hola = new LinkedList<String>();
		hola.add("No sé");
		
		
		ArrayList<String> hello = new ArrayList<String>(3);
		hello.add("buenas");
		hello.add("No");
		hello.add("Si");
		hello.add("prueba");
		System.out.println(hello);
	}

}
