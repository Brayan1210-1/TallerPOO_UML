package com.taller.seccion3;

public class Ejercicio2 {

	public static void main(String[] args) {
	
	String[] productos = { "Tampico", "Vive100", "Bonice"
	};

	}

}
