package com.taller.seccion3;

public class Ejercicio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
