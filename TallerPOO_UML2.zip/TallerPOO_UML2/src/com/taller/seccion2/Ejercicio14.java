package com.taller.seccion2;
import java.util.Arrays;
import java.util.List;

public class Ejercicio14 {

	public static void main(String[] args) {

		String[] nombres = {"Pepito" , "Juan", "Alex"};
      List<String> personas = Arrays.asList(nombres);
   
      
      for(String nombre : personas) {
    	  System.out.println("Hola " + nombre);
      }
}
}
