package com.taller.seccion2;
import java.util.Scanner;
public class Ejercicio1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println(" ¿El número es mayor a 5? ");
		double numero = sc.nextDouble();
		
		//Implementación del if simple
		if ( numero > 5) {
			System.out.println(" El número "+ numero + " es mayor a 5");
		} else {
			System.out.println(" El número "+ numero + " NO es mayor a 5");

		}
	System.out.println("");
	
		//Implementacion del if-else 
	System.out.println(" Ingrese su edad ");
	 int edad = sc.nextInt();
	 
		if ( edad <= 12 && edad >= 0) {
			System.out.println(" Eres un niño ");
			
		}  else if ( edad > 12 && edad < 18) {
			System.out.println(" Eres un adolescente ");
			
		} else if ( edad >= 18 && edad <= 59 ) {
			 System.out.println(" eres un adulto "); 
			 
		} else if ( edad > 59 ) {
			 System.out.println(" eres un anciano ");
			 
	}   else if ( edad < 0) {
		System.out.println(" La edad no puede ser menor a 0 ");
	}
		

		sc.close();		
}
}
