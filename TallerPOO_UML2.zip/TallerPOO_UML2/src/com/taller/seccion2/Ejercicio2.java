package com.taller.seccion2;
import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
	      Scanner sc = new Scanner(System.in);
		
	      //Se le solicita al usuario que ingrese la edad
		System.out.println(" Ingrese su edad ");
		 int edad = sc.nextInt();
		 
		 //if para comprobar que es un niño
			if ( edad <= 12 && edad >= 0) {
				System.out.println(" Eres un niño ");
				
		//else if para comprobar si es un adolescente		
			}  else if ( edad > 12 && edad < 18) {
				System.out.println(" Eres un adolescente ");
				
		//else if para saber si es un adulto		
			} else if ( edad >= 18 && edad <= 59 ) {
				 System.out.println(" eres un adulto "); 
				 
		//Else if para saber si es un anciano		 
			} else if ( edad > 59 ) {
				 System.out.println(" eres un anciano ");
			}

		sc.close();	
	}

}
