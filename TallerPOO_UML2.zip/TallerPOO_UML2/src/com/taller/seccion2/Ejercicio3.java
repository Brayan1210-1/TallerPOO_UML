package com.taller.seccion2;
import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//Impresión del menú
		System.out.println(" Menú de saludos ");
		System.out.println(" Ingrese un número para escoger una opción ");
		System.out.println("");
		System.out.println("1. Saludar al mundo");
		System.out.println("2. Saludar a Juan ");
		System.out.println("3. Saludar al mundo en inglés ");
		
		//Lectura de la opción
		int opcion = sc.nextInt();
		
		//swtich para cada caso
		switch (opcion) {
		case 1:
			System.out.println(" ¡Hola mundo! ");
			break;
		case 2:
			System.out.println(" ¡Hola Juan! ");
			break;
		case 3:
			System.out.println(" ¡Hello world! ");
			break;
		default:
			System.out.println(" ¡Ingresa un número del menú! ");
		}
sc.close();
	}
}
