package com.taller.seccion2;
import java.util.Scanner;

public class Ejercicio6 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		int contraseña = 1234;
		int ingreso;
		
		do {
		System.out.println("introduce la contraseña ");
		System.out.println();
		System.out.println(" contraseña: " + contraseña);
		
	    ingreso = sc.nextInt();
	    
		}while (ingreso !=contraseña);
		
		System.out.println(" ¡Bienvenido! ");
	
  sc.close();
	}

}
