package com.taller.seccion2;

import java.util.ArrayList;
import java.util.Collections;

public class Ejercicio12 {

	public static void main(String[] args) {

		ArrayList<Integer> listaNumeros = new ArrayList<>();
		listaNumeros.add(54);
		listaNumeros.add(1);
		listaNumeros.add(10);
		listaNumeros.add(17);
		listaNumeros.add(9);
		
		
		Collections.sort(listaNumeros);
		
		for(int numero : listaNumeros) {
			System.out.println(numero);
		}
	}

}
