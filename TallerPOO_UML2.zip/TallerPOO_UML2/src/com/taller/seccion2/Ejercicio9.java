package com.taller.seccion2;

public class Ejercicio9 {

	public static void main(String[] args) {
	int[] numerosNaturales = { 1, 2 , 3, 4, 5, 6};
	
		//Bucle for each
		for (int numero: numerosNaturales) {
		System.out.println("Los números naturales: " + numero);
		}
	}
}
