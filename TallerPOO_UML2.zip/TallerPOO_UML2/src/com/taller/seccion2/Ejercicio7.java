package com.taller.seccion2;



public class Ejercicio7 {

	public static void main(String[] args) {
		//bucle for con break
		for (int i = 0; i < 20; i++) {
			if (i == 5) {
			     break;
			}
			System.out.println(i);
			
		
		}
		
		System.out.println("");
	//bucle for con continue
	for (int i = 0; i <10; i++ ) {
		if (i == 2) {
			continue;
		}
		System.out.println(i);
	}
	

		
		

	}
}
