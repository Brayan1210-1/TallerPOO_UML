package com.taller.seccion2;

public class Ejercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num = 1;
	}

}
