package com.taller.seccion1;

public class Ejercicio11 {

	public static void main(String[] args) {
		
		//Bloque para obtener un número aleatorio e imprimirlo
		double numeroAleator = Math.random();
		System.out.print(" Número aleatorio: ");
        System.out.println(numeroAleator);
	}

}
