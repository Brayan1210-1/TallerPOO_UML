package com.taller.seccion1;

public class Ejercicio8 {

	public static void main(String[] args)  {
	
		String cadenaN = "juan";
		
		
		try {
			
		//convertir el String a double y int
      int numeroEntero = Integer.parseInt(cadenaN);
      double numeroDecimal = Double.parseDouble(cadenaN);
      
    //Imprimir la conversion de String a double y int
      System.out.println(numeroEntero);
 		System.out.println(numeroDecimal);
 		System.out.println("");
 		
 		    //Parte catch para la excepción
		} catch (NumberFormatException mensaje) {
		System.out.println(" Error al convertir la cadena " + mensaje);
		}
			System.out.println(" No se detuvo ");
		
  
 
 	 
		

	}

	
		
	}


