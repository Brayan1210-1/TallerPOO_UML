package com.taller.seccion1;

public class Ejercicio12 {

	public static void main(String[] args) {
	String saludo = "Hola";
	String obj = "Mundo";
	int edad = 80;
	
	
   System.out.printf("%s %s %d", saludo, obj, edad);
	}

}
