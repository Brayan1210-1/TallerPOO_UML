package com.taller.seccion1;

public class Ejercicio9 {

	public static void main(String[] args) {
		
		//Declaracion de la constante Pi
		final double valorPi = 3.1416;
		System.out.println(valorPi);

	}

}
