package com.taller.seccion1;
import java.util.Scanner;
public class Ejercicio10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		//sysout para pedirle al usuario que ingrese un número y la lectura del número
		System.out.println(" Ingrese un número param saber su raiz cuadrada y potencia");
		double numero = sc.nextDouble();
		
		//calcula la raíz cuadrada del número ingresado y la imprime
		double Raiz = Math.sqrt(numero);
   System.out.println("La raiz es: " + Raiz);
   System.out.println("");
   
   //sysout y escaner para obtener el exponente 
   System.out.println(" Ingrese la potencia a la que quiere elevar " + numero);
   double exponente = sc.nextDouble();
   
   
   //Math para calcular la potencia e imprimirla
         double potencia = Math.pow(numero, exponente);
         System.out.println(potencia);
   sc.close();
	}

}
